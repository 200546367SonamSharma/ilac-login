package com.example.ilac_login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/* Declares a new Kotlin class named SuccessActivity that extends AppCompatActivity.
This means SuccessActivity inherits all behaviors and features of AppCompatActivity.
 */
class FailureActivity : AppCompatActivity() {

    // Override the onCreate method, called when the activity is first created
    override fun onCreate(savedInstanceState: Bundle?)
    {
        // Call the superclass implementation of onCreate
        super.onCreate(savedInstanceState)

        // Set the activity's layout to activity_failure.xml
        setContentView(R.layout.activity_failure)

    }
}

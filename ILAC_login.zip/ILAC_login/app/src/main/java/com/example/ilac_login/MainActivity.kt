package com.example.ilac_login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

// Define a new Activity class named MainActivity that inherits from AppCompatActivity
class MainActivity : AppCompatActivity() {

    // Variable to track login attempts
    private var loginAttempts = 0

    // Override the onCreate method, called when the activity is first created
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Call the superclass implementation of onCreate
        setContentView(R.layout.activity_main) // Set the activity's layout to activity_main.xml

        // Initialize views from the layout using findViewById
        val usernameInput = findViewById<EditText>(R.id.username_input)
        val passwordInput = findViewById<EditText>(R.id.password_input)
        val loginButton = findViewById<Button>(R.id.login_btn)

        // Define correct username and password for login validation
        val correctUsername = "200546367"
        val correctPassword = "4804"

        // Set an OnClickListener on the loginButton
        loginButton.setOnClickListener {
            // Retrieve the username and password entered by the user
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()

            // Check if the entered username and password match the correct credentials
            if (username == correctUsername && password == correctPassword) {
                // Display a success message using Toast
                Toast.makeText(this, getString(R.string.login_successful1) + " " + getString(R.string.login_successful2), Toast.LENGTH_SHORT).show()

                // Create an Intent to start the SuccessActivity
                val intent = Intent(this, SuccessActivity::class.java)
                startActivity(intent) // Start the SuccessActivity
            } else {
                // Increment loginAttempts as login failed
                loginAttempts++

                // Check if loginAttempts exceeds 3
                if (loginAttempts >= 3) {
                    // If loginAttempts >= 3, start FailureActivity
                    val intent = Intent(this, FailureActivity::class.java)
                    startActivity(intent) // Start the FailureActivity
                } else {
                    // Display an unsuccessful login message using Toast
                    Toast.makeText(this, getString(R.string.login_unsuccessful), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

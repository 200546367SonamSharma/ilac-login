package com.example.ilac_login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/*Defines a new Kotlin class named FailureActivity that extends AppCompatActivity.
This means FailureActivity inherits all behaviors and features of AppCompatActivity
 */

class SuccessActivity : AppCompatActivity()
{

    // Override the onCreate method, which is called when the activity is first created
    override fun onCreate(savedInstanceState: Bundle?)
    {
        // Call the superclass implementation of onCreate
        super.onCreate(savedInstanceState)

        // Set the activity's layout to activity_success.xml
        setContentView(R.layout.activity_success)

    }
}

